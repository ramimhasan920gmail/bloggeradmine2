export interface MovieData {
  id: number;
  title: string;
  original_title: string;
  overview: string;
  poster_path: string;
  release_date: string;
  vote_average: number;
  genre_ids: number[];
  genres?: { id: number; name: string }[];
  runtime?: number;
  budget?: number;
  credits?: {
    cast: { name: string }[];
    crew: { name: string; job: string }[];
  };
}

export interface AppSettings {
  tmdbApiKey: string;
  bloggerApiKey: string;
  bloggerBlogId: string;
  defaultLabels: string;
  baseDownloadUrl: string;
}

export interface DownloadLink {
  label: string;
  url: string;
}

export interface Season {
  number: number;
  episodes: DownloadLink[];
}
