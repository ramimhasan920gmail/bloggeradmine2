import axios from 'axios';
import { MovieData } from '../types';

const TMDB_BASE_URL = 'https://api.themoviedb.org/3';

export const searchMovies = async (query: string, apiKey: string) => {
  if (!apiKey) throw new Error('TMDB API Key is required');
  const response = await axios.get(`${TMDB_BASE_URL}/search/multi`, {
    params: {
      api_key: apiKey,
      query,
      include_adult: false,
    },
  });
  return response.data.results;
};

export const getMovieDetails = async (id: number, type: 'movie' | 'tv', apiKey: string): Promise<MovieData> => {
  if (!apiKey) throw new Error('TMDB API Key is required');
  const response = await axios.get(`${TMDB_BASE_URL}/${type}/${id}`, {
    params: {
      api_key: apiKey,
      append_to_response: 'credits',
    },
  });
  return response.data;
};

export const getPosterUrl = (path: string, size: string = 'w500') => {
  if (!path) return 'https://via.placeholder.com/500x750?text=No+Poster';
  return `https://image.tmdb.org/t/p/${size}${path}`;
};
