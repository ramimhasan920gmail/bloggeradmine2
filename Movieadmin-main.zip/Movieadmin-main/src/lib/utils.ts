import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export const getSettings = () => {
  const settings = localStorage.getItem('movie_admin_settings');
  return settings ? JSON.parse(settings) : {
    tmdbApiKey: '',
    bloggerApiKey: '',
    bloggerBlogId: '',
    defaultLabels: 'Movies, Latest',
    baseDownloadUrl: '',
  };
};

export const saveSettings = (settings: any) => {
  localStorage.setItem('movie_admin_settings', JSON.stringify(settings));
};
