import React from 'react';
import { motion } from 'motion/react';
import { Film, LogIn } from 'lucide-react';

interface LoginProps {
  onLogin: () => void;
}

export default function Login({ onLogin }: LoginProps) {
  const handleConnect = async () => {
    try {
      const response = await fetch('/api/auth/url');
      if (!response.ok) throw new Error('Failed to get auth URL');
      const { url } = await response.json();

      const authWindow = window.open(
        url,
        'oauth_popup',
        'width=600,height=700'
      );

      if (!authWindow) {
        alert('Please allow popups to connect your Google account.');
      }
    } catch (error) {
      console.error('OAuth error:', error);
    }
  };

  React.useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      if (event.data?.type === 'OAUTH_AUTH_SUCCESS') {
        onLogin();
      }
    };
    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, [onLogin]);

  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-md w-full bg-white rounded-3xl shadow-2xl overflow-hidden"
      >
        <div className="p-8 text-center space-y-6">
          <div className="inline-flex p-4 bg-orange-500 rounded-2xl shadow-lg shadow-orange-500/30">
            <Film className="w-10 h-10 text-white" />
          </div>
          
          <div>
            <h1 className="text-3xl font-bold text-slate-900">MovieAdmin <span className="text-orange-500">Pro</span></h1>
            <p className="text-slate-500 mt-2">Sign in to manage your movie portal.</p>
          </div>

          <button
            onClick={handleConnect}
            className="w-full flex items-center justify-center gap-3 bg-slate-900 text-white py-4 rounded-2xl font-bold hover:bg-slate-800 transition-all active:scale-95 shadow-xl"
          >
            <LogIn className="w-5 h-5" />
            Continue with Google
          </button>

          <p className="text-xs text-slate-400">
            By signing in, you agree to connect your Blogger account for post management.
          </p>
        </div>
        
        <div className="bg-slate-50 p-6 border-t border-slate-100">
          <div className="flex items-center justify-center gap-8 opacity-50 grayscale">
            <img src="https://www.gstatic.com/images/branding/googlelogo/2x/googlelogo_color_92x30dp.png" alt="Google" className="h-5" />
            <span className="text-xl font-bold text-slate-400">Blogger</span>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
