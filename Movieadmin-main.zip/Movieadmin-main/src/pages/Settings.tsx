import React, { useState, useEffect } from 'react';
import { Save, Key, Globe, Tag, Link as LinkIcon } from 'lucide-react';
import { getSettings, saveSettings } from '../lib/utils';
import { motion } from 'motion/react';

export default function Settings() {
  const [settings, setSettings] = useState(getSettings());
  const [saved, setSaved] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    saveSettings(settings);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-slate-900">Settings</h1>
        <p className="text-slate-500 mt-1">Configure your API keys and default preferences.</p>
      </div>

      <form onSubmit={handleSave} className="max-w-2xl space-y-6">
        <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100 space-y-6">
          <div className="space-y-4">
            <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <Key className="w-5 h-5 text-orange-500" />
              API Configuration
            </h2>
            
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700">TMDB API Key</label>
              <input
                type="password"
                value={settings.tmdbApiKey}
                onChange={(e) => setSettings({ ...settings, tmdbApiKey: e.target.value })}
                className="w-full px-4 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-orange-500 outline-none transition-all"
                placeholder="Enter your TMDB API Key"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700">Blogger API Key</label>
              <input
                type="password"
                value={settings.bloggerApiKey}
                onChange={(e) => setSettings({ ...settings, bloggerApiKey: e.target.value })}
                className="w-full px-4 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-orange-500 outline-none transition-all"
                placeholder="Enter your Blogger API Key"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700">Blogger Blog ID</label>
              <input
                type="text"
                value={settings.bloggerBlogId}
                onChange={(e) => setSettings({ ...settings, bloggerBlogId: e.target.value })}
                className="w-full px-4 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-orange-500 outline-none transition-all"
                placeholder="Enter your Blog ID"
              />
            </div>
          </div>

          <hr className="border-slate-100" />

          <div className="space-y-4">
            <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <Globe className="w-5 h-5 text-blue-500" />
              Default Preferences
            </h2>

            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700 flex items-center gap-2">
                <Tag className="w-4 h-4" />
                Default Labels
              </label>
              <input
                type="text"
                value={settings.defaultLabels}
                onChange={(e) => setSettings({ ...settings, defaultLabels: e.target.value })}
                className="w-full px-4 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-orange-500 outline-none transition-all"
                placeholder="Movies, Latest, HD"
              />
              <p className="text-xs text-slate-400">Comma separated labels for your posts.</p>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700 flex items-center gap-2">
                <LinkIcon className="w-4 h-4" />
                Base Download URL Prefix
              </label>
              <input
                type="text"
                value={settings.baseDownloadUrl}
                onChange={(e) => setSettings({ ...settings, baseDownloadUrl: e.target.value })}
                className="w-full px-4 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-orange-500 outline-none transition-all"
                placeholder="https://your-shortener.com/?url="
              />
              <p className="text-xs text-slate-400">Automatically prefix all download links.</p>
            </div>
          </div>
        </div>

        <div className="flex items-center justify-between">
          {saved && (
            <motion.p
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              className="text-green-600 font-medium text-sm"
            >
              Settings saved successfully!
            </motion.p>
          )}
          <button
            type="submit"
            className="ml-auto flex items-center gap-2 bg-orange-500 text-white px-8 py-3 rounded-xl font-bold hover:bg-orange-600 shadow-lg shadow-orange-500/30 transition-all active:scale-95"
          >
            <Save className="w-5 h-5" />
            Save Changes
          </button>
        </div>
      </form>
    </div>
  );
}
