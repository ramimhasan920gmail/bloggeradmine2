import React, { useState, useEffect } from 'react';
import { MovieSearch } from '../components/MovieSearch';
import { getMovieDetails, getPosterUrl } from '../lib/tmdb';
import { getSettings } from '../lib/utils';
import { MovieData, DownloadLink, Season } from '../types';
import { motion } from 'motion/react';
import { Send, FileCode, Plus, Trash2, ChevronDown, ChevronUp, ExternalLink, Copy, Check, Loader2 } from 'lucide-react';

export default function CreatePost() {
  const [selectedMovie, setSelectedMovie] = useState<MovieData | null>(null);
  const [type, setType] = useState<'movie' | 'tv'>('movie');
  const [loading, setLoading] = useState(false);
  const [downloadLinks, setDownloadLinks] = useState<DownloadLink[]>([]);
  const [seasons, setSeasons] = useState<Season[]>([]);
  const [labels, setLabels] = useState('');
  const [customTitle, setCustomTitle] = useState('');
  const [copied, setCopied] = useState(false);

  const settings = getSettings();

  const handleSelect = async (id: number, mediaType: 'movie' | 'tv') => {
    setLoading(true);
    setType(mediaType);
    try {
      const data = await getMovieDetails(id, mediaType, settings.tmdbApiKey);
      setSelectedMovie(data);
      setCustomTitle(`${data.title || (data as any).name} (${new Date(data.release_date || (data as any).first_air_date).getFullYear()})`);
      setLabels(settings.defaultLabels);
      
      if (mediaType === 'tv') {
        setSeasons([]);
      } else {
        setDownloadLinks([{ label: 'Download', url: '' }]);
      }
    } catch (error) {
      console.error(error);
      alert('Failed to fetch details.');
    } finally {
      setLoading(false);
    }
  };

  const generatePostHtml = () => {
    if (!selectedMovie) return '';

    const title = customTitle;
    const year = new Date(selectedMovie.release_date || (selectedMovie as any).first_air_date).getFullYear();
    const poster_url = getPosterUrl(selectedMovie.poster_path);
    const genre = selectedMovie.genres?.map(g => g.name).join(', ') || 'N/A';
    const rating = selectedMovie.vote_average ? selectedMovie.vote_average.toFixed(1) : 'N/A';
    const release_date = selectedMovie.release_date || (selectedMovie as any).first_air_date;
    const language = (selectedMovie as any).original_language?.toUpperCase() || 'N/A';
    const director = selectedMovie.credits?.crew.find(c => c.job === 'Director')?.name || 'N/A';
    const budget = selectedMovie.budget ? `$${selectedMovie.budget.toLocaleString()}` : 'N/A';
    const cast = selectedMovie.credits?.cast.slice(0, 5).map(c => c.name).join(', ') || 'N/A';
    const plot = selectedMovie.overview;

    let linksHtml = '';
    if (type === 'movie') {
      linksHtml = downloadLinks.map(link => {
        const finalUrl = settings.baseDownloadUrl ? `${settings.baseDownloadUrl}${encodeURIComponent(link.url)}` : link.url;
        return `<li><a href="${finalUrl}" class="download-btn" target="_blank">${link.label}</a></li>`;
      }).join('\n');
    } else {
      linksHtml = seasons.map(season => `
        <div class="season-container">
          <h4>Season ${season.number}</h4>
          <ul class="seasons">
            ${season.episodes.map(ep => {
              const finalUrl = settings.baseDownloadUrl ? `${settings.baseDownloadUrl}${encodeURIComponent(ep.url)}` : ep.url;
              return `<li><a href="${finalUrl}" class="download-btn" target="_blank">${ep.label}</a></li>`;
            }).join('\n')}
          </ul>
        </div>
      `).join('\n');
    }

    return `
<div class="movie-card-vertical">
  <h2>${title}</h2>
  <div class="poster">
    <img src="${poster_url}" alt="${title} Poster">
  </div>
  <div class="info-grid">
    <p><b>Genre:</b> <span class="movie-genre">${genre}</span></p>
    <p><b>IMDb:</b> <span class="imdb-rating">⭐ ${rating}</span></p>
    <p><b>Released:</b> <span class="movie-release">${release_date}</span></p>
    <p><b>Language:</b> <span class="movie-language">${language}</span></p>
    <p><b>Director:</b> <span class="movie-director">${director}</span></p>
    <p><b>Budget:</b> <span class="movie-budget">${budget}</span></p>
  </div>
  <p><b>Cast:</b> <span class="movie-cast">${cast}</span></p>
  <p><b>Plot:</b> <span class="movie-plot">${plot}</span></p>
  <h3>Download Links</h3>
  <ul class="seasons">
    ${linksHtml}
  </ul>
</div>

<style>
  .movie-card-vertical { max-width: 500px; margin: 30px auto; padding: 25px; border-radius: 20px; background: #fff; font-family: 'Inter', sans-serif; box-shadow: 0 15px 35px rgba(0,0,0,0.1); text-align: center; border: 1px solid #eee; }
  .movie-card-vertical h2 { color: #1a202c; font-size: 24px; margin-bottom: 15px; }
  .movie-card-vertical .poster img { width: 100%; max-width: 280px; border-radius: 12px; margin-bottom: 20px; box-shadow: 0 8px 16px rgba(0,0,0,0.15); }
  .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; text-align: left; margin-bottom: 15px; background: #f8fafc; padding: 15px; border-radius: 12px; }
  .movie-card-vertical p { font-size: 14px; color: #4a5568; line-height: 1.6; margin: 8px 0; text-align: left; }
  .movie-card-vertical h3 { margin-top: 25px; border-top: 1px solid #edf2f7; padding-top: 15px; color: #2d3748; }
  .seasons { list-style: none; padding: 0; display: flex; flex-wrap: wrap; justify-content: center; gap: 10px; margin-top: 15px; }
  .download-btn { display: inline-block; padding: 10px 20px; background: #f97316; color: #fff !important; text-decoration: none !important; border-radius: 8px; font-weight: bold; transition: 0.2s; }
  .download-btn:hover { background: #ea580c; transform: translateY(-2px); }
  .season-container { margin-top: 20px; }
  .season-container h4 { color: #4a5568; font-size: 16px; margin-bottom: 10px; }
</style>
    `.trim();
  };

  const addSeason = () => {
    setSeasons([...seasons, { number: seasons.length + 1, episodes: [] }]);
  };

  const addEpisodes = (seasonIndex: number, range: string) => {
    const [start, end] = range.split('-').map(Number);
    if (isNaN(start) || isNaN(end)) return;
    
    const newEpisodes = [];
    for (let i = start; i <= end; i++) {
      newEpisodes.push({ label: `Episode ${i}`, url: '' });
    }
    
    const newSeasons = [...seasons];
    newSeasons[seasonIndex].episodes = [...newSeasons[seasonIndex].episodes, ...newEpisodes];
    setSeasons(newSeasons);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(generatePostHtml());
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const publishToBlogger = async (isDraft: boolean) => {
    if (!settings.bloggerBlogId) {
      alert('Please set your Blogger Blog ID in settings.');
      return;
    }

    setLoading(true);
    try {
      const response = await fetch('/api/blogger/posts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          blogId: settings.bloggerBlogId,
          title: customTitle,
          content: generatePostHtml(),
          labels: labels,
          isDraft,
        }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to publish');
      }

      alert(isDraft ? 'Saved as draft!' : 'Published successfully!');
    } catch (error: any) {
      console.error(error);
      alert(`Error: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Create New Post</h1>
          <p className="text-slate-500 mt-1">Search TMDB and generate your Blogger post.</p>
        </div>
        {selectedMovie && (
          <button
            onClick={() => setSelectedMovie(null)}
            className="text-sm font-medium text-slate-500 hover:text-slate-900"
          >
            Change Movie
          </button>
        )}
      </div>

      {!selectedMovie ? (
        <MovieSearch onSelect={handleSelect} />
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 space-y-6">
              <div className="space-y-4">
                <h2 className="text-lg font-bold text-slate-900">Post Details</h2>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-700">Post Title</label>
                  <input
                    type="text"
                    value={customTitle}
                    onChange={(e) => setCustomTitle(e.target.value)}
                    className="w-full px-4 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-orange-500 outline-none"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-700">Labels (Tags)</label>
                  <input
                    type="text"
                    value={labels}
                    onChange={(e) => setLabels(e.target.value)}
                    className="w-full px-4 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-orange-500 outline-none"
                  />
                </div>
              </div>

              <hr className="border-slate-100" />

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h2 className="text-lg font-bold text-slate-900">Download Links</h2>
                  {type === 'tv' && (
                    <button
                      onClick={addSeason}
                      className="flex items-center gap-1 text-sm font-bold text-orange-500 hover:text-orange-600"
                    >
                      <Plus className="w-4 h-4" /> Add Season
                    </button>
                  )}
                </div>

                {type === 'movie' ? (
                  <div className="space-y-3">
                    {downloadLinks.map((link, idx) => (
                      <div key={idx} className="flex gap-2">
                        <input
                          type="text"
                          placeholder="Label (e.g. 720p HD)"
                          value={link.label}
                          onChange={(e) => {
                            const newLinks = [...downloadLinks];
                            newLinks[idx].label = e.target.value;
                            setDownloadLinks(newLinks);
                          }}
                          className="w-1/3 px-4 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-orange-500 outline-none"
                        />
                        <input
                          type="text"
                          placeholder="Download URL"
                          value={link.url}
                          onChange={(e) => {
                            const newLinks = [...downloadLinks];
                            newLinks[idx].url = e.target.value;
                            setDownloadLinks(newLinks);
                          }}
                          className="flex-1 px-4 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-orange-500 outline-none"
                        />
                        <button
                          onClick={() => setDownloadLinks(downloadLinks.filter((_, i) => i !== idx))}
                          className="p-2 text-slate-400 hover:text-red-500"
                        >
                          <Trash2 className="w-5 h-5" />
                        </button>
                      </div>
                    ))}
                    <button
                      onClick={() => setDownloadLinks([...downloadLinks, { label: 'Download', url: '' }])}
                      className="text-sm font-bold text-slate-500 hover:text-slate-900 flex items-center gap-1"
                    >
                      <Plus className="w-4 h-4" /> Add Link
                    </button>
                  </div>
                ) : (
                  <div className="space-y-6">
                    {seasons.map((season, sIdx) => (
                      <div key={sIdx} className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-4">
                        <div className="flex items-center justify-between">
                          <h3 className="font-bold text-slate-900">Season {season.number}</h3>
                          <div className="flex gap-4">
                            <input
                              type="text"
                              placeholder="Add Range (e.g. 1-10)"
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') {
                                  addEpisodes(sIdx, (e.target as HTMLInputElement).value);
                                  (e.target as HTMLInputElement).value = '';
                                }
                              }}
                              className="text-xs px-3 py-1 rounded-lg border border-slate-200 outline-none"
                            />
                            <button
                              onClick={() => setSeasons(seasons.filter((_, i) => i !== sIdx))}
                              className="text-slate-400 hover:text-red-500"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                        <div className="grid grid-cols-1 gap-2">
                          {season.episodes.map((ep, eIdx) => (
                            <div key={eIdx} className="flex gap-2">
                              <input
                                type="text"
                                value={ep.label}
                                onChange={(e) => {
                                  const newSeasons = [...seasons];
                                  newSeasons[sIdx].episodes[eIdx].label = e.target.value;
                                  setSeasons(newSeasons);
                                }}
                                className="w-1/4 text-xs px-3 py-1 rounded-lg border border-slate-200 outline-none"
                              />
                              <input
                                type="text"
                                placeholder="Episode URL"
                                value={ep.url}
                                onChange={(e) => {
                                  const newSeasons = [...seasons];
                                  newSeasons[sIdx].episodes[eIdx].url = e.target.value;
                                  setSeasons(newSeasons);
                                }}
                                className="flex-1 text-xs px-3 py-1 rounded-lg border border-slate-200 outline-none"
                              />
                              <button
                                onClick={() => {
                                  const newSeasons = [...seasons];
                                  newSeasons[sIdx].episodes = newSeasons[sIdx].episodes.filter((_, i) => i !== eIdx);
                                  setSeasons(newSeasons);
                                }}
                                className="text-slate-400 hover:text-red-500"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
              <h2 className="text-lg font-bold text-slate-900 mb-4">Preview</h2>
              <div className="border border-slate-100 rounded-xl overflow-hidden bg-slate-50 p-4 max-h-[500px] overflow-y-auto">
                <div dangerouslySetInnerHTML={{ __html: generatePostHtml() }} />
              </div>
            </div>

            <div className="flex flex-col gap-3">
              <button
                onClick={copyToClipboard}
                className="flex items-center justify-center gap-2 w-full py-4 rounded-2xl bg-slate-900 text-white font-bold hover:bg-slate-800 transition-all active:scale-95"
              >
                {copied ? <Check className="w-5 h-5 text-green-400" /> : <Copy className="w-5 h-5" />}
                {copied ? 'Copied HTML!' : 'Copy HTML Code'}
              </button>
              <button
                onClick={() => publishToBlogger(false)}
                disabled={loading}
                className="flex items-center justify-center gap-2 w-full py-4 rounded-2xl bg-orange-500 text-white font-bold hover:bg-orange-600 shadow-lg shadow-orange-500/30 transition-all active:scale-95 disabled:opacity-50"
              >
                {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
                Publish to Blogger
              </button>
              <button
                onClick={() => publishToBlogger(true)}
                disabled={loading}
                className="text-sm font-medium text-slate-500 hover:text-slate-900"
              >
                Save as Draft
              </button>
              <p className="text-center text-xs text-slate-400">
                Publishing requires Blogger API configuration in settings.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
