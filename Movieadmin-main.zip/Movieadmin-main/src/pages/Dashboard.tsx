import React from 'react';
import { motion } from 'motion/react';
import { Film, Eye, Send, TrendingUp, PlusCircle, Settings } from 'lucide-react';
import { cn } from '../lib/utils';

const stats = [
  { label: 'Total Posts', value: '1,284', icon: Film, color: 'bg-blue-500' },
  { label: 'Total Views', value: '45.2K', icon: Eye, color: 'bg-purple-500' },
  { label: 'Published Today', value: '12', icon: Send, color: 'bg-green-500' },
  { label: 'Engagement', value: '+14.5%', icon: TrendingUp, color: 'bg-orange-500' },
];

export default function Dashboard() {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-slate-900">Welcome back, Admin</h1>
        <p className="text-slate-500 mt-1">Here's what's happening with your movie portal today.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, i) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-500">{stat.label}</p>
                <p className="text-2xl font-bold text-slate-900 mt-1">{stat.value}</p>
              </div>
              <div className={cn("p-3 rounded-xl text-white", stat.color)}>
                <stat.icon className="w-6 h-6" />
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <h2 className="text-lg font-bold text-slate-900 mb-4">Recent Activity</h2>
          <div className="space-y-4">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="flex items-center gap-4 p-3 hover:bg-slate-50 rounded-xl transition-colors">
                <div className="w-10 h-10 rounded-lg bg-slate-100 flex items-center justify-center text-slate-500">
                  <Film className="w-5 h-5" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-slate-900">Maa Ka Sum (2026) Published</p>
                  <p className="text-xs text-slate-500">2 hours ago • Draft saved</p>
                </div>
                <span className="text-xs font-medium px-2 py-1 bg-green-100 text-green-700 rounded-full">Success</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <h2 className="text-lg font-bold text-slate-900 mb-4">Quick Actions</h2>
          <div className="grid grid-cols-2 gap-4">
            <button className="flex flex-col items-center justify-center p-6 rounded-2xl border-2 border-dashed border-slate-200 hover:border-orange-500 hover:bg-orange-50 transition-all group">
              <PlusCircle className="w-8 h-8 text-slate-400 group-hover:text-orange-500 mb-2" />
              <span className="text-sm font-medium text-slate-600 group-hover:text-orange-700">New Movie Post</span>
            </button>
            <button className="flex flex-col items-center justify-center p-6 rounded-2xl border-2 border-dashed border-slate-200 hover:border-blue-500 hover:bg-blue-50 transition-all group">
              <Settings className="w-8 h-8 text-slate-400 group-hover:text-blue-500 mb-2" />
              <span className="text-sm font-medium text-slate-600 group-hover:text-blue-700">Update Settings</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
