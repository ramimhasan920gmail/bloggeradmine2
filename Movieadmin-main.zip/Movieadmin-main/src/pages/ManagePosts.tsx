import React from 'react';
import { Search, Filter, MoreVertical, ExternalLink, Edit2, Trash2 } from 'lucide-react';

export default function ManagePosts() {
  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Manage Posts</h1>
          <p className="text-slate-500 mt-1">View and edit your published movie posts.</p>
        </div>
        <div className="flex gap-3">
          <div className="relative">
            <input
              type="text"
              placeholder="Filter posts..."
              className="pl-10 pr-4 py-2 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-orange-500 text-sm"
            />
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          </div>
          <button className="flex items-center gap-2 px-4 py-2 rounded-xl border border-slate-200 hover:bg-slate-50 transition-colors text-sm font-medium">
            <Filter className="w-4 h-4" />
            Filter
          </button>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-100">
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Post Title</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Labels</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Published</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Views</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {[1, 2, 3, 4, 5].map((i) => (
              <tr key={i} className="hover:bg-slate-50 transition-colors group">
                <td className="px-6 py-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-14 bg-slate-100 rounded-lg overflow-hidden flex-shrink-0">
                      <img
                        src={`https://picsum.photos/seed/${i}/100/140`}
                        alt="Poster"
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div>
                      <p className="text-sm font-bold text-slate-900">Maa Ka Sum (2026)</p>
                      <p className="text-xs text-slate-400">ID: 82736451928374</p>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <div className="flex flex-wrap gap-1">
                    <span className="px-2 py-0.5 bg-blue-50 text-blue-600 rounded-md text-[10px] font-bold uppercase">Movies</span>
                    <span className="px-2 py-0.5 bg-orange-50 text-orange-600 rounded-md text-[10px] font-bold uppercase">Latest</span>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <p className="text-sm text-slate-600">Apr 03, 2026</p>
                  <p className="text-xs text-slate-400">10:45 AM</p>
                </td>
                <td className="px-6 py-4">
                  <p className="text-sm font-medium text-slate-900">1,284</p>
                </td>
                <td className="px-6 py-4 text-right">
                  <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button className="p-2 text-slate-400 hover:text-blue-500 hover:bg-blue-50 rounded-lg transition-all">
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button className="p-2 text-slate-400 hover:text-orange-500 hover:bg-orange-50 rounded-lg transition-all">
                      <ExternalLink className="w-4 h-4" />
                    </button>
                    <button className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="flex items-center justify-between px-2">
        <p className="text-sm text-slate-500">Showing 1 to 5 of 128 posts</p>
        <div className="flex gap-2">
          <button className="px-4 py-2 rounded-xl border border-slate-200 text-sm font-medium disabled:opacity-50" disabled>Previous</button>
          <button className="px-4 py-2 rounded-xl border border-slate-200 text-sm font-medium hover:bg-slate-50">Next</button>
        </div>
      </div>
    </div>
  );
}
