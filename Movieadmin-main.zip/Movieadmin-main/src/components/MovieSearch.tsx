import React, { useState } from 'react';
import { Search, Loader2, Film, Tv } from 'lucide-react';
import { searchMovies, getPosterUrl } from '../lib/tmdb';
import { getSettings } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';

interface MovieSearchProps {
  onSelect: (id: number, type: 'movie' | 'tv') => void;
}

export function MovieSearch({ onSelect }: MovieSearchProps) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const settings = getSettings();

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;
    
    setLoading(true);
    try {
      const data = await searchMovies(query, settings.tmdbApiKey);
      setResults(data.filter((r: any) => r.media_type === 'movie' || r.media_type === 'tv'));
    } catch (error) {
      console.error(error);
      alert('Search failed. Check your TMDB API Key in settings.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <form onSubmit={handleSearch} className="relative">
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search for a movie or TV series..."
          className="w-full pl-12 pr-4 py-4 rounded-2xl bg-white border border-slate-200 shadow-sm focus:ring-2 focus:ring-orange-500 outline-none transition-all text-lg"
        />
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-6 h-6" />
        <button
          type="submit"
          disabled={loading}
          className="absolute right-3 top-1/2 -translate-y-1/2 bg-slate-900 text-white px-6 py-2 rounded-xl font-medium hover:bg-slate-800 transition-all disabled:opacity-50"
        >
          {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : 'Search'}
        </button>
      </form>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
        <AnimatePresence>
          {results.map((result) => (
            <motion.div
              key={`${result.media_type}-${result.id}`}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              whileHover={{ y: -5 }}
              onClick={() => onSelect(result.id, result.media_type)}
              className="bg-white rounded-xl overflow-hidden shadow-sm border border-slate-100 cursor-pointer group"
            >
              <div className="relative aspect-[2/3]">
                <img
                  src={getPosterUrl(result.poster_path)}
                  alt={result.title || result.name}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute top-2 right-2 px-2 py-1 bg-black/60 backdrop-blur-md rounded-lg text-[10px] font-bold text-white uppercase flex items-center gap-1">
                  {result.media_type === 'movie' ? <Film className="w-3 h-3" /> : <Tv className="w-3 h-3" />}
                  {result.media_type}
                </div>
              </div>
              <div className="p-3">
                <h3 className="text-sm font-bold text-slate-900 line-clamp-1 group-hover:text-orange-500 transition-colors">
                  {result.title || result.name}
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  {new Date(result.release_date || result.first_air_date).getFullYear() || 'N/A'}
                </p>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}
